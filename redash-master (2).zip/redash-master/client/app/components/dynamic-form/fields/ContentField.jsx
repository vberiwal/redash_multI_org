export default function ContentField({ field }) {
  return field.content;
}
